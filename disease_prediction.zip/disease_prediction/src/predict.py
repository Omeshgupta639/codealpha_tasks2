"""Predict disease probability for patients in a CSV file.

    python src/predict.py --dataset heart --input sample_inputs/heart_sample.csv
"""
import argparse
import json
import os

import joblib
import numpy as np
import pandas as pd

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["heart", "diabetes", "breast_cancer"])
    ap.add_argument("--input", required=True, help="CSV with the same feature columns as training")
    ap.add_argument("--model_dir", default="models")
    a = ap.parse_args()

    model = joblib.load(os.path.join(a.model_dir, f"{a.dataset}_best_model.joblib"))
    meta = json.load(open(os.path.join(a.model_dir, f"{a.dataset}_meta.json")))
    df = pd.read_csv(a.input)
    missing = [c for c in meta["features"] if c not in df.columns]
    if missing:
        raise SystemExit(f"Input is missing columns: {missing}")
    df = df[meta["features"]].replace("?", np.nan).astype(float)
    if a.dataset == "diabetes":  # same cleaning as training: 0 means missing here
        cols = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
        df[cols] = df[cols].replace(0, np.nan)
    prob = model.predict_proba(df)[:, 1]
    print(f"Model: {meta['model']} ({meta['title']})")
    for i, p in enumerate(prob):
        print(f"Patient {i + 1}: P(disease) = {p:.1%} -> "
              f"{'HIGH RISK' if p >= 0.5 else 'low risk'}")
    print("\nFor educational use only - not a medical diagnosis.")
