"""Dataset loaders for the three UCI medical datasets.

Each loader returns (X: DataFrame, y: Series[0/1], categorical_columns: list).
y == 1 always means "disease present".

Download behaviour
------------------
* Breast Cancer (Wisconsin Diagnostic, UCI) ships inside scikit-learn -> works offline.
* Heart Disease (Cleveland, UCI) is downloaded from the UCI repository.
* Diabetes (Pima Indians, UCI/NIDDK) is downloaded from OpenML (fallback: a public mirror).
Downloaded files are cached in data/. If you have no internet, put your own CSV in data/:
  data/heart_disease.csv  (13 feature columns + 'target')
  data/diabetes.csv       (8 Pima columns + 'Outcome')
"""
import os

import numpy as np
import pandas as pd
from sklearn.datasets import fetch_openml, load_breast_cancer

HEART_URL = ("https://archive.ics.uci.edu/ml/machine-learning-databases/"
             "heart-disease/processed.cleveland.data")
HEART_COLS = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach",
              "exang", "oldpeak", "slope", "ca", "thal", "target"]
HEART_CATEGORICAL = ["cp", "restecg", "slope", "thal"]

PIMA_MIRROR = ("https://raw.githubusercontent.com/jbrownlee/Datasets/master/"
               "pima-indians-diabetes.data.csv")
PIMA_COLS = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin",
             "BMI", "DiabetesPedigreeFunction", "Age", "Outcome"]
# In the Pima data a value of 0 in these columns is physiologically impossible -> missing
PIMA_ZERO_AS_MISSING = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]


def load_breast_cancer_data(data_dir="data"):
    d = load_breast_cancer(as_frame=True)
    X = d.data.copy()
    # sklearn encodes 0 = malignant, 1 = benign. We predict disease (malignant) = 1.
    y = (1 - d.target).rename("target").astype(int)
    return X, y, []


def load_heart(data_dir="data"):
    path = os.path.join(data_dir, "heart_disease.csv")
    if os.path.exists(path):
        df = pd.read_csv(path)
    else:
        try:
            df = pd.read_csv(HEART_URL, header=None, names=HEART_COLS, na_values="?")
            os.makedirs(data_dir, exist_ok=True)
            df.to_csv(path, index=False)
        except Exception as e:
            raise RuntimeError(
                f"Could not download the Heart Disease data ({e}). Download "
                f"'processed.cleveland.data' from the UCI repository, add the header "
                f"{HEART_COLS} and save it as {path}.")
    y = (df["target"] > 0).astype(int)          # 0 = healthy, 1-4 = disease
    X = df.drop(columns="target")
    return X, y, HEART_CATEGORICAL


def load_diabetes(data_dir="data"):
    path = os.path.join(data_dir, "diabetes.csv")
    if os.path.exists(path):
        df = pd.read_csv(path)
    else:
        df = None
        try:  # primary: OpenML copy of the UCI/NIDDK Pima dataset
            raw = fetch_openml(data_id=37, as_frame=True, parser="auto").frame
            raw.columns = PIMA_COLS
            raw["Outcome"] = (raw["Outcome"].astype(str) == "tested_positive").astype(int)
            df = raw
        except Exception:
            try:  # fallback: public mirror
                df = pd.read_csv(PIMA_MIRROR, header=None, names=PIMA_COLS)
            except Exception as e:
                raise RuntimeError(
                    f"Could not download the Diabetes data ({e}). Save the Pima CSV "
                    f"with columns {PIMA_COLS} as {path}.")
        os.makedirs(data_dir, exist_ok=True)
        df.to_csv(path, index=False)
    df = df.copy()
    df[PIMA_ZERO_AS_MISSING] = df[PIMA_ZERO_AS_MISSING].replace(0, np.nan)
    y = df["Outcome"].astype(int)
    X = df.drop(columns="Outcome")
    return X, y, []


DATASETS = {
    "heart": ("Heart Disease (UCI Cleveland)", load_heart),
    "diabetes": ("Diabetes (UCI Pima Indians)", load_diabetes),
    "breast_cancer": ("Breast Cancer (UCI Wisconsin Diagnostic)", load_breast_cancer_data),
}
