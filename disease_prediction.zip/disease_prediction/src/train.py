"""Disease prediction from medical data.

Trains and compares SVM, Logistic Regression, Random Forest and XGBoost on
Heart Disease, Diabetes and Breast Cancer datasets (UCI).

    python src/train.py                       # all datasets
    python src/train.py --datasets heart diabetes
"""
import argparse
import json
import os
import sys
import warnings

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, RocCurveDisplay, accuracy_score,
                             classification_report, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.svm import SVC

sys.path.insert(0, os.path.dirname(__file__))
from data_loader import DATASETS  # noqa: E402

warnings.filterwarnings("ignore")
SEED = 42


def make_preprocessor(X, categorical):
    numeric = [c for c in X.columns if c not in categorical]
    num_pipe = Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("sc", StandardScaler())])
    transformers = [("num", num_pipe, numeric)]
    if categorical:
        cat_pipe = Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                             ("oh", OneHotEncoder(handle_unknown="ignore"))])
        transformers.append(("cat", cat_pipe, categorical))
    return ColumnTransformer(transformers)


def build_models():
    models = {
        "SVM": (SVC(probability=True, random_state=SEED),
                {"clf__C": [0.1, 1, 10], "clf__kernel": ["rbf", "linear"],
                 "clf__gamma": ["scale", "auto"]}),
        "Logistic Regression": (LogisticRegression(max_iter=3000),
                                {"clf__C": [0.01, 0.1, 1, 10]}),
        "Random Forest": (RandomForestClassifier(random_state=SEED),
                          {"clf__n_estimators": [100, 300],
                           "clf__max_depth": [None, 5, 10],
                           "clf__min_samples_leaf": [1, 3]}),
    }
    try:
        from xgboost import XGBClassifier
        models["XGBoost"] = (XGBClassifier(eval_metric="logloss", random_state=SEED, n_jobs=1),
                             {"clf__n_estimators": [100, 300], "clf__max_depth": [3, 5],
                              "clf__learning_rate": [0.05, 0.1]})
    except ImportError:
        print("WARNING: xgboost is not installed -> XGBoost skipped. "
              "Install it with `pip install xgboost`.")
    return models


def run_eda(X, y, title, out):
    fig, ax = plt.subplots(1, 2, figsize=(13, 5))
    y.value_counts().sort_index().plot.bar(ax=ax[0], color=["#4C9F70", "#D1495B"])
    ax[0].set_xticklabels(["No disease (0)", "Disease (1)"], rotation=0)
    ax[0].set_title(f"{title}: class distribution")
    corr = pd.concat([X.select_dtypes("number"), y.rename("target")], axis=1).corr()
    sns.heatmap(corr, cmap="coolwarm", center=0, ax=ax[1], cbar_kws={"shrink": .8})
    ax[1].set_title("Correlation heatmap")
    plt.tight_layout(); plt.savefig(os.path.join(out, "eda.png"), dpi=140); plt.close()


def evaluate(name, pipe, X_te, y_te):
    pred = pipe.predict(X_te)
    prob = pipe.predict_proba(X_te)[:, 1]
    return {"Model": name,
            "Accuracy": accuracy_score(y_te, pred),
            "Precision": precision_score(y_te, pred),
            "Recall": recall_score(y_te, pred),
            "F1": f1_score(y_te, pred),
            "ROC-AUC": roc_auc_score(y_te, prob)}, pred, prob


def run_dataset(key, args):
    title, loader = DATASETS[key]
    print(f"\n{'=' * 70}\n{title}\n{'=' * 70}")
    X, y, cat = loader(args.data_dir)
    print(f"Samples: {len(X)} | Features: {X.shape[1]} | Positive rate: {y.mean():.2%} "
          f"| Missing values: {int(X.isna().sum().sum())}")
    out = os.path.join(args.out_dir, key); os.makedirs(out, exist_ok=True)
    run_eda(X, y, title, out)

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=SEED)
    cv = StratifiedKFold(n_splits=args.cv, shuffle=True, random_state=SEED)

    rows, fitted, cv_scores, preds = [], {}, {}, {}
    for name, (est, grid) in build_models().items():
        pipe = Pipeline([("prep", make_preprocessor(X, cat)), ("clf", est)])
        gs = GridSearchCV(pipe, grid, cv=cv, scoring="roc_auc", n_jobs=-1)
        gs.fit(X_tr, y_tr)
        metrics, pred, prob = evaluate(name, gs.best_estimator_, X_te, y_te)
        metrics["CV ROC-AUC"] = gs.best_score_
        metrics["Best params"] = {k.replace("clf__", ""): v for k, v in gs.best_params_.items()}
        rows.append(metrics); fitted[name] = gs.best_estimator_
        cv_scores[name] = gs.best_score_; preds[name] = (pred, prob)
        print(f"{name:20s} CV-AUC={gs.best_score_:.3f} | test Acc={metrics['Accuracy']:.3f} "
              f"Rec={metrics['Recall']:.3f} F1={metrics['F1']:.3f} AUC={metrics['ROC-AUC']:.3f}")

    res = pd.DataFrame(rows)
    res.to_csv(os.path.join(out, "results.csv"), index=False)

    # Confusion matrices
    n = len(fitted)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4))
    axes = np.atleast_1d(axes)
    for ax, (name, (pred, _)) in zip(axes, preds.items()):
        ConfusionMatrixDisplay.from_predictions(
            y_te, pred, display_labels=["No disease", "Disease"], cmap="Blues",
            colorbar=False, ax=ax)
        ax.set_title(name)
    plt.tight_layout(); plt.savefig(os.path.join(out, "confusion_matrices.png"), dpi=140); plt.close()

    # ROC curves
    plt.figure(figsize=(6, 5))
    for name, (_, prob) in preds.items():
        RocCurveDisplay.from_predictions(y_te, prob, name=name, ax=plt.gca())
    plt.plot([0, 1], [0, 1], "k--", lw=1); plt.title(f"{title}: ROC curves")
    plt.tight_layout(); plt.savefig(os.path.join(out, "roc_curves.png"), dpi=140); plt.close()

    # Random Forest feature importance
    rf = fitted["Random Forest"]
    names = rf.named_steps["prep"].get_feature_names_out()
    imp = pd.Series(rf.named_steps["clf"].feature_importances_, index=names)
    imp = imp.sort_values().tail(10)
    plt.figure(figsize=(7, 5)); imp.plot.barh(color="#2E86AB")
    plt.title(f"{title}: top-10 features (Random Forest)")
    plt.tight_layout(); plt.savefig(os.path.join(out, "feature_importance.png"), dpi=140); plt.close()

    # Save best model (selected by cross-validation, never by test score)
    best_name = max(cv_scores, key=cv_scores.get)
    os.makedirs(args.model_dir, exist_ok=True)
    joblib.dump(fitted[best_name], os.path.join(args.model_dir, f"{key}_best_model.joblib"))
    best_row = next(r for r in rows if r["Model"] == best_name)
    meta = {"dataset": key, "title": title, "model": best_name,
            "features": list(X.columns),
            "test_metrics": {k: float(best_row[k]) for k in
                             ["Accuracy", "Precision", "Recall", "F1", "ROC-AUC"]}}
    json.dump(meta, open(os.path.join(args.model_dir, f"{key}_meta.json"), "w"), indent=2)
    print(f"Best model by CV: {best_name}")
    print(classification_report(y_te, preds[best_name][0],
                                target_names=["No disease", "Disease"]))
    return title, res, best_name


def md_table(df):
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(f"{v:.3f}" if isinstance(v, float) else str(v)
                                       for v in r) + " |")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Disease prediction (UCI datasets)")
    ap.add_argument("--datasets", nargs="+", default=list(DATASETS), choices=list(DATASETS))
    ap.add_argument("--data_dir", default="data")
    ap.add_argument("--out_dir", default="outputs")
    ap.add_argument("--model_dir", default="models")
    ap.add_argument("--cv", type=int, default=5)
    args = ap.parse_args()

    summary = ["# Results summary (auto-generated)\n",
               "Metrics are on a held-out stratified 20% test set. Models were tuned with "
               f"{args.cv}-fold cross-validation (ROC-AUC) on the training set only.\n"]
    for key in args.datasets:
        title, res, best = run_dataset(key, args)
        show = res[["Model", "Accuracy", "Precision", "Recall", "F1", "ROC-AUC", "CV ROC-AUC"]]
        summary += [f"\n## {title}\n", md_table(show), f"\n\n**Best model (by CV ROC-AUC): {best}**\n"]
        summary.append("\nBest hyper-parameters:\n")
        summary += [f"- {r['Model']}: `{r['Best params']}`" for _, r in res.iterrows()]
        summary.append("")
    os.makedirs(args.out_dir, exist_ok=True)
    with open(os.path.join(args.out_dir, "results_summary.md"), "w") as f:
        f.write("\n".join(summary))
    print(f"\nSaved plots, results and summary to '{args.out_dir}/', models to '{args.model_dir}/'")


if __name__ == "__main__":
    main()
