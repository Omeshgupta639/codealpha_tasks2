# Task 4: Disease Prediction from Medical Data

**Objective:** Predict the possibility of disease from patient data.
**Approach:** Classification on structured medical datasets.
**Algorithms:** SVM, Logistic Regression, Random Forest, XGBoost.
**Datasets (UCI):** Heart Disease (Cleveland), Diabetes (Pima Indians), Breast Cancer (Wisconsin Diagnostic).

> Educational project. Not a medical device and not for clinical use.

## Project structure
```
disease_prediction/
├── README.md
├── REPORT.md                  # methodology, evaluation, discussion
├── requirements.txt
├── LICENSE
├── .gitignore
├── src/
│   ├── data_loader.py         # loads/downloads the 3 datasets
│   ├── train.py               # preprocessing, tuning, evaluation, plots, saving
│   └── predict.py             # predict from a CSV of patients
├── notebooks/Disease_Prediction.ipynb   # run everything in Jupyter / Colab
├── sample_inputs/             # example patient CSVs for predict.py
├── data/                      # datasets are cached here
├── outputs/                   # plots, results.csv, results_summary.md (generated)
└── models/                    # best model per dataset (generated)
```

## Quick start
```bash
pip install -r requirements.txt
python src/train.py                      # trains all 4 models on all 3 datasets
python src/predict.py --dataset heart --input sample_inputs/heart_sample.csv
```
Useful options: `--datasets heart diabetes`, `--cv 5`, `--data_dir`, `--out_dir`.

Heart and Diabetes data are downloaded automatically (UCI / OpenML) and cached in `data/`.
Breast Cancer ships with scikit-learn. With no internet, place `heart_disease.csv`
(13 features + `target`) and `diabetes.csv` (8 Pima features + `Outcome`) in `data/`.

## Pipeline
1. **Cleaning:** `?` and impossible zeros (Pima glucose, BP, skin, insulin, BMI) become missing values.
2. **Preprocessing (inside the sklearn Pipeline, so no leakage):** median imputation + standard scaling for numeric features; most-frequent imputation + one-hot encoding for categorical heart features.
3. **Split:** stratified 80/20 train/test.
4. **Tuning:** `GridSearchCV`, 5-fold stratified CV, ROC-AUC, on the training set only.
5. **Evaluation:** accuracy, precision, recall, F1, ROC-AUC on the test set; confusion matrices, ROC curves, feature importances.
6. **Model selection:** best model per dataset chosen by CV score (not test score) and saved to `models/`.

## Results
After running `train.py`, see `outputs/results_summary.md` and `outputs/<dataset>/` (EDA, confusion matrices, ROC curves, feature importance).

## Submission
**GitHub**
```bash
cd disease_prediction
git init && git add . && git commit -m "Task 4: Disease prediction"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
**Google Drive:** upload the whole `disease_prediction` folder (or the zip) to Drive and share the link.
