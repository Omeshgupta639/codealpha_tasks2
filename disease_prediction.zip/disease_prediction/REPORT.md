# Disease Prediction from Medical Data: Project Report

## 1. Objective
Predict the possibility of a disease from structured patient data using classification
techniques, and compare four algorithms (SVM, Logistic Regression, Random Forest, XGBoost)
on three UCI datasets.

## 2. Datasets
| Dataset | Source | Samples | Features | Positive class |
|---|---|---|---|---|
| Heart Disease | UCI Cleveland | 303 | 13 (age, sex, chest pain, blood pressure, cholesterol, ECG, ...) | Disease present (target 1-4) |
| Diabetes | UCI / NIDDK Pima Indians | 768 | 8 (glucose, BMI, insulin, age, ...) | Diabetic |
| Breast Cancer | UCI Wisconsin Diagnostic | 569 | 30 (cell nucleus measurements) | Malignant |

## 3. Data preparation
- Heart: `?` entries (columns `ca`, `thal`) treated as missing; the 0-4 severity label is binarised (0 vs 1-4).
- Diabetes: zeros in Glucose, BloodPressure, SkinThickness, Insulin and BMI are physiologically impossible and treated as missing.
- Breast Cancer: scikit-learn encodes malignant as 0, so the label is flipped so that 1 means disease.
- Imputation, scaling and encoding are fitted inside a scikit-learn `Pipeline`, so test data never influences preprocessing.

## 4. Methods
- **SVM:** C, kernel (rbf/linear), gamma tuned.
- **Logistic Regression:** regularisation strength C tuned.
- **Random Forest:** trees, depth, minimum leaf size tuned.
- **XGBoost:** trees, depth, learning rate tuned.
- Hyper-parameters are tuned with 5-fold stratified cross-validation optimising ROC-AUC on the training split (80%).

## 5. Evaluation protocol
Held-out stratified 20% test set. Metrics: accuracy, precision, recall, F1, ROC-AUC.
In medical screening, **recall** (missed cases) is usually costlier than a false alarm, so recall and ROC-AUC are reported alongside accuracy. The saved model per dataset is chosen by cross-validation score, not test score, to avoid optimistic bias.

## 6. Results
Generated automatically by `python src/train.py`:
- `outputs/results_summary.md`: metric tables and best hyper-parameters
- `outputs/<dataset>/results.csv`, `confusion_matrices.png`, `roc_curves.png`, `feature_importance.png`, `eda.png`

Paste the tables from `outputs/results_summary.md` here before submitting.

## 7. Discussion points
- Breast Cancer is the easiest of the three (very high ROC-AUC for all models); Pima Diabetes is the hardest, with noisy features and many missing values.
- Linear models are often competitive on small tabular datasets; tree ensembles help most when there are non-linear interactions.
- Random Forest feature importances indicate which clinical variables drive predictions (for example chest pain type and thalassemia for heart disease, glucose and BMI for diabetes).

## 8. Limitations
- Small datasets (a few hundred rows), so test metrics have wide confidence intervals; cross-validated estimates are more stable.
- Single-centre, historical data; results may not generalise to other populations.
- Decision threshold is fixed at 0.5; a screening setting would tune it for higher recall.
- Educational project only, not for clinical decision-making.

## 9. Reproducibility
Fixed random seed (42); dependencies in `requirements.txt`; one command (`python src/train.py`) regenerates every table, plot and model.
