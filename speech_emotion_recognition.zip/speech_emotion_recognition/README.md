# Task 2: Emotion Recognition from Speech

**Objective:** Recognize human emotions (happy, angry, sad, ...) from speech audio.
**Approach:** Speech signal processing (MFCC) + deep learning (CNN + BiLSTM).

## Project structure
```
speech_emotion_recognition/
├── README.md
├── requirements.txt
├── src/
│   ├── download_datasets.py   # downloads RAVDESS + TESS into data/
│   ├── train.py               # features, model, training, evaluation
│   └── predict.py             # inference on a single wav file
├── notebooks/
│   └── Emotion_Recognition_Colab.ipynb   # one-click run on Google Colab
├── data/                      # datasets land here
└── outputs/                   # model, curves, confusion matrix, report
```

## Method
1. **Datasets:** RAVDESS (24 actors, 8 emotions) and TESS (2 actresses, 7 emotions); EMO-DB can be added by extending `parse_label`.
2. **Preprocessing:** resample to 22.05 kHz, trim silence, pad/crop to 3 s.
3. **Features:** 40 MFCCs per frame (Mel-Frequency Cepstral Coefficients), standardized with training statistics.
4. **Augmentation (train only):** noise, pitch shift, time stretch.
5. **Model:** Conv1D(64) → Conv1D(128) (with BatchNorm, pooling, dropout) → BiLSTM(128) → Dense(128) → Softmax.
6. **Training:** Adam, early stopping, LR scheduling; 70/15/15 stratified train/val/test split.

## How to run
```bash
pip install -r requirements.txt
python src/download_datasets.py
python src/train.py --data_dir data --out_dir outputs --epochs 60
python src/predict.py some_audio.wav --model_dir outputs
```
Or open `notebooks/Emotion_Recognition_Colab.ipynb` in Google Colab (Runtime → GPU) and run all cells.

## Results
Fill in after training (copy from console / `outputs/`):

| Metric | Value |
|---|---|
| Test accuracy | _TBD_ |
| Datasets used | RAVDESS + TESS |

Artifacts produced in `outputs/`: `emotion_model.keras`, `best_model.keras`, `training_curves.png`, `confusion_matrix.png`, `preproc.npz`.

## Notes / limitations
- Random file-level splits let the same speaker appear in train and test, which inflates accuracy. A speaker-independent split is a stricter evaluation.
- TESS has only two speakers, so combined results lean on RAVDESS for speaker diversity.
