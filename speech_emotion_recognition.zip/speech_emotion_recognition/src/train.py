"""
TASK 2: Emotion Recognition from Speech
---------------------------------------
Objective : Recognize human emotions (happy, angry, sad, ...) from speech audio.
Approach  : Speech signal processing (MFCC features) + deep learning (CNN + LSTM).
Datasets  : RAVDESS and/or TESS (EMO-DB can be added via a label parser).

Usage
-----
    pip install librosa tensorflow scikit-learn matplotlib seaborn numpy
    python emotion_recognition.py --data_dir ./data --epochs 60

Expected data layout (extract the downloaded datasets anywhere under --data_dir):
    data/
      RAVDESS/Actor_01/03-01-05-01-01-01-01.wav ...
      TESS/OAF_angry/OAF_back_angry.wav ...
The script walks the folder recursively and detects each file's dataset by its name.
"""

import argparse
import os
import random

import librosa
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import tensorflow as tf
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras import layers, models, callbacks

SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ----------------------------- Configuration -------------------------------
SR = 22050              # sampling rate
DURATION = 3.0          # seconds (clips padded / trimmed to this length)
N_MFCC = 40             # number of MFCC coefficients
HOP = 512
N_SAMPLES = int(SR * DURATION)

# RAVDESS: 3rd field of filename encodes emotion
RAVDESS_MAP = {
    "01": "neutral", "02": "calm", "03": "happy", "04": "sad",
    "05": "angry", "06": "fearful", "07": "disgust", "08": "surprised",
}
# TESS: emotion is the last token of the filename (e.g. OAF_back_angry.wav)
TESS_MAP = {
    "neutral": "neutral", "happy": "happy", "sad": "sad", "angry": "angry",
    "fear": "fearful", "disgust": "disgust", "ps": "surprised", "surprised": "surprised",
}


# ----------------------------- Data loading --------------------------------
def parse_label(path):
    """Return the emotion label for a wav file, or None if it can't be parsed."""
    name = os.path.splitext(os.path.basename(path))[0]
    parts = name.split("-")
    if len(parts) == 7 and parts[2] in RAVDESS_MAP:          # RAVDESS
        return RAVDESS_MAP[parts[2]]
    last = name.split("_")[-1].lower()                         # TESS
    return TESS_MAP.get(last)


def collect_files(data_dir):
    files, labels = [], []
    for root, _, fnames in os.walk(data_dir):
        for f in fnames:
            if f.lower().endswith(".wav"):
                p = os.path.join(root, f)
                lab = parse_label(p)
                if lab is not None:
                    files.append(p)
                    labels.append(lab)
    if not files:
        raise RuntimeError(f"No labelled .wav files found under '{data_dir}'.")
    return files, labels


# ----------------------------- Feature extraction --------------------------
def load_audio(path):
    y, _ = librosa.load(path, sr=SR, duration=DURATION)
    y, _ = librosa.effects.trim(y, top_db=30)                  # remove silence
    if len(y) < N_SAMPLES:
        y = np.pad(y, (0, N_SAMPLES - len(y)))
    return y[:N_SAMPLES]


def augment(y):
    """Random augmentation: noise / pitch shift / time stretch."""
    choice = random.choice(["noise", "pitch", "stretch"])
    if choice == "noise":
        y = y + 0.005 * np.random.randn(len(y)) * np.max(np.abs(y) + 1e-9)
    elif choice == "pitch":
        y = librosa.effects.pitch_shift(y, sr=SR, n_steps=random.choice([-2, -1, 1, 2]))
    else:
        y = librosa.effects.time_stretch(y, rate=random.choice([0.9, 1.1]))
    if len(y) < N_SAMPLES:
        y = np.pad(y, (0, N_SAMPLES - len(y)))
    return y[:N_SAMPLES]


def extract_mfcc(y):
    """MFCC matrix of shape (time_steps, N_MFCC)."""
    mfcc = librosa.feature.mfcc(y=y, sr=SR, n_mfcc=N_MFCC, hop_length=HOP)
    return mfcc.T.astype(np.float32)


def build_features(files, labels, do_augment=False):
    X, y_out = [], []
    for i, (f, lab) in enumerate(zip(files, labels)):
        y = load_audio(f)
        X.append(extract_mfcc(y))
        y_out.append(lab)
        if do_augment:                                         # one extra augmented copy
            X.append(extract_mfcc(augment(y)))
            y_out.append(lab)
        if (i + 1) % 200 == 0:
            print(f"  processed {i + 1}/{len(files)} files")
    return np.array(X), np.array(y_out)


# ----------------------------- Model ---------------------------------------
def build_model(input_shape, n_classes):
    """CNN (local spectral patterns) -> LSTM (temporal dynamics) -> Dense."""
    inp = layers.Input(shape=input_shape)
    x = layers.Conv1D(64, 5, padding="same", activation="relu")(inp)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling1D(2)(x)
    x = layers.Dropout(0.25)(x)

    x = layers.Conv1D(128, 5, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling1D(2)(x)
    x = layers.Dropout(0.25)(x)

    x = layers.Bidirectional(layers.LSTM(128, return_sequences=False))(x)
    x = layers.Dropout(0.4)(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.4)(x)
    out = layers.Dense(n_classes, activation="softmax")(x)

    model = models.Model(inp, out)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),
                  loss="sparse_categorical_crossentropy",
                  metrics=["accuracy"])
    return model


# ----------------------------- Evaluation / plots --------------------------
def plot_history(h, path):
    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    ax[0].plot(h.history["accuracy"], label="train")
    ax[0].plot(h.history["val_accuracy"], label="val")
    ax[0].set_title("Accuracy"); ax[0].set_xlabel("epoch"); ax[0].legend()
    ax[1].plot(h.history["loss"], label="train")
    ax[1].plot(h.history["val_loss"], label="val")
    ax[1].set_title("Loss"); ax[1].set_xlabel("epoch"); ax[1].legend()
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()


def plot_confusion(cm, classes, path):
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=classes, yticklabels=classes)
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.title("Confusion Matrix")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()


# ----------------------------- Main ----------------------------------------
def main(args):
    os.makedirs(args.out_dir, exist_ok=True)

    print("Scanning dataset ...")
    files, labels = collect_files(args.data_dir)
    print(f"Found {len(files)} files. Class counts:",
          {k: labels.count(k) for k in sorted(set(labels))})

    # Split FILES first (so augmented copies never leak into val/test)
    f_train, f_tmp, l_train, l_tmp = train_test_split(
        files, labels, test_size=0.3, stratify=labels, random_state=SEED)
    f_val, f_test, l_val, l_test = train_test_split(
        f_tmp, l_tmp, test_size=0.5, stratify=l_tmp, random_state=SEED)

    print("Extracting MFCC features (train, with augmentation) ...")
    X_train, y_train = build_features(f_train, l_train, do_augment=True)
    print("Extracting MFCC features (val) ...")
    X_val, y_val = build_features(f_val, l_val)
    print("Extracting MFCC features (test) ...")
    X_test, y_test = build_features(f_test, l_test)

    # Normalise with training statistics
    mean, std = X_train.mean(axis=(0, 1), keepdims=True), X_train.std(axis=(0, 1), keepdims=True) + 1e-8
    X_train, X_val, X_test = [(a - mean) / std for a in (X_train, X_val, X_test)]

    le = LabelEncoder().fit(y_train)
    y_train, y_val, y_test = [le.transform(a) for a in (y_train, y_val, y_test)]
    classes = list(le.classes_)

    model = build_model(X_train.shape[1:], len(classes))
    model.summary()

    cbs = [
        callbacks.EarlyStopping(monitor="val_accuracy", patience=12, restore_best_weights=True),
        callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=5, min_lr=1e-5),
        callbacks.ModelCheckpoint(os.path.join(args.out_dir, "best_model.keras"),
                                  monitor="val_accuracy", save_best_only=True),
    ]
    hist = model.fit(X_train, y_train, validation_data=(X_val, y_val),
                     epochs=args.epochs, batch_size=args.batch_size, callbacks=cbs)

    # Evaluate
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"\nTest accuracy: {acc:.4f} | Test loss: {loss:.4f}")
    y_pred = np.argmax(model.predict(X_test), axis=1)
    print(classification_report(y_test, y_pred, target_names=classes))

    plot_history(hist, os.path.join(args.out_dir, "training_curves.png"))
    plot_confusion(confusion_matrix(y_test, y_pred), classes,
                   os.path.join(args.out_dir, "confusion_matrix.png"))

    # Save artefacts needed for inference
    model.save(os.path.join(args.out_dir, "emotion_model.keras"))
    np.savez(os.path.join(args.out_dir, "preproc.npz"), mean=mean, std=std, classes=np.array(classes))
    print(f"Saved model, plots and preprocessing stats to '{args.out_dir}/'")


# ----------------------------- Inference helper ----------------------------
def predict_emotion(wav_path, model_dir="outputs"):
    """Predict the emotion of a single audio file with a trained model."""
    model = tf.keras.models.load_model(os.path.join(model_dir, "emotion_model.keras"))
    p = np.load(os.path.join(model_dir, "preproc.npz"), allow_pickle=True)
    x = (extract_mfcc(load_audio(wav_path))[None] - p["mean"]) / p["std"]
    probs = model.predict(x, verbose=0)[0]
    return p["classes"][int(np.argmax(probs))], dict(zip(p["classes"], probs.round(3)))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Speech Emotion Recognition (MFCC + CNN-LSTM)")
    ap.add_argument("--data_dir", default="./data", help="folder containing RAVDESS / TESS wav files")
    ap.add_argument("--out_dir", default="./outputs")
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--batch_size", type=int, default=32)
    main(ap.parse_args())
