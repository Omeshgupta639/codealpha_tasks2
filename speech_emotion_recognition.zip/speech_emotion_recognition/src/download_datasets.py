"""Download RAVDESS (Zenodo) and TESS (Kaggle) into ./data.

    python src/download_datasets.py            # both
    python src/download_datasets.py --only ravdess
"""
import argparse
import os
import shutil
import urllib.request
import zipfile

from tqdm import tqdm

RAVDESS_URL = "https://zenodo.org/records/1188976/files/Audio_Speech_Actors_01-24.zip?download=1"
TESS_KAGGLE = "ejlok1/toronto-emotional-speech-set-tess"


class _Bar(tqdm):
    def update_to(self, b=1, bsize=1, tsize=None):
        if tsize is not None:
            self.total = tsize
        self.update(b * bsize - self.n)


def download_ravdess(data_dir):
    dest = os.path.join(data_dir, "RAVDESS")
    if os.path.isdir(dest) and any(os.scandir(dest)):
        print("RAVDESS already present, skipping.")
        return
    os.makedirs(dest, exist_ok=True)
    zpath = os.path.join(data_dir, "ravdess.zip")
    with _Bar(unit="B", unit_scale=True, desc="RAVDESS") as bar:
        urllib.request.urlretrieve(RAVDESS_URL, zpath, reporthook=bar.update_to)
    with zipfile.ZipFile(zpath) as z:
        z.extractall(dest)
    os.remove(zpath)
    print("RAVDESS ready ->", dest)


def download_tess(data_dir):
    dest = os.path.join(data_dir, "TESS")
    if os.path.isdir(dest) and any(os.scandir(dest)):
        print("TESS already present, skipping.")
        return
    import kagglehub
    src = kagglehub.dataset_download(TESS_KAGGLE)
    shutil.copytree(src, dest, dirs_exist_ok=True)
    print("TESS ready ->", dest)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data")
    ap.add_argument("--only", choices=["ravdess", "tess"])
    a = ap.parse_args()
    os.makedirs(a.data_dir, exist_ok=True)
    if a.only in (None, "ravdess"):
        download_ravdess(a.data_dir)
    if a.only in (None, "tess"):
        try:
            download_tess(a.data_dir)
        except Exception as e:
            print("TESS auto-download failed:", e)
            print("Download manually from https://www.kaggle.com/datasets/" + TESS_KAGGLE +
                  " and extract into data/TESS/")
