"""Predict the emotion of one audio file with the trained model.

    python src/predict.py path/to/audio.wav --model_dir outputs
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from train import predict_emotion  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("wav")
    ap.add_argument("--model_dir", default="outputs")
    a = ap.parse_args()
    label, probs = predict_emotion(a.wav, a.model_dir)
    print("Predicted emotion:", label)
    for k, v in sorted(probs.items(), key=lambda kv: -kv[1]):
        print(f"  {k:10s} {v:.3f}")
