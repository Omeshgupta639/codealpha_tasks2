"""CRNN + CTC: recognise a whole SEQUENCE of characters without segmenting it.

Demo task (no extra download needed): multi-digit strings built on the fly by concatenating
MNIST digits. The same architecture/loss works for real words - just swap the dataset
(e.g. IAM handwriting, or synthetic text rendered with fonts) and the character set.

    python src/crnn_train.py --epochs 15
"""
import argparse
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets

sys.path.insert(0, os.path.dirname(__file__))
from models import CRNN  # noqa: E402
from seq_utils import compose_sequence, ctc_greedy_decode, edit_distance  # noqa: E402

MEAN, STD = 0.1307, 0.3081


class DigitSequences(Dataset):
    """Random digit strings. seed=None -> new random samples every epoch (training);
    a fixed seed gives a fixed, reproducible set (validation / test)."""

    def __init__(self, images, labels, size, seed=None):
        self.images, self.labels, self.size, self.seed = images, labels, size, seed

    def __len__(self):
        return self.size

    def __getitem__(self, i):
        rng = np.random.default_rng(None if self.seed is None else self.seed + i)
        img, digits = compose_sequence(self.images, self.labels, rng)
        x = (torch.from_numpy(img).float().div(255) - MEAN) / STD
        return x.unsqueeze(0), torch.tensor([d + 1 for d in digits])   # +1: index 0 is the CTC blank


def collate(batch):
    xs, ys = zip(*batch)
    return torch.stack(xs), torch.cat(ys), torch.tensor([len(y) for y in ys])


def evaluate(model, loader, device, ctc=None):
    model.eval()
    seq_ok = total = 0
    dist = chars = 0
    loss_sum = 0.0
    shown = []
    with torch.no_grad():
        for x, tgt, tlen in loader:
            out = model(x.to(device))                                   # (T,B,C)
            if ctc is not None:
                ilen = torch.full((x.size(0),), out.size(0), dtype=torch.long)
                loss_sum += ctc(out.cpu(), tgt, ilen, tlen).item() * x.size(0)
            preds = ctc_greedy_decode(out.cpu().numpy())
            off = 0
            for b, n in enumerate(tlen.tolist()):
                truth = [t - 1 for t in tgt[off:off + n].tolist()]
                off += n
                pred = [p - 1 for p in preds[b]]
                seq_ok += pred == truth
                dist += edit_distance(pred, truth); chars += n; total += 1
                if len(shown) < 12:
                    shown.append((x[b, 0].numpy() * STD + MEAN, truth, pred))
    return {"loss": loss_sum / total, "seq_acc": seq_ok / total, "cer": dist / chars}, shown


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--batch_size", type=int, default=64)
    ap.add_argument("--train_size", type=int, default=20000)
    ap.add_argument("--eval_size", type=int, default=2000)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--data_dir", default="data")
    ap.add_argument("--out_dir", default="outputs/crnn")
    ap.add_argument("--model_dir", default="models")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    torch.manual_seed(a.seed); np.random.seed(a.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    os.makedirs(a.out_dir, exist_ok=True); os.makedirs(a.model_dir, exist_ok=True)

    tr = datasets.MNIST(a.data_dir, train=True, download=True)
    te = datasets.MNIST(a.data_dir, train=False, download=True)
    xtr, ytr = tr.data.numpy(), tr.targets.numpy()
    xte, yte = te.data.numpy(), te.targets.numpy()
    # digit pools: train (55k) / val (5k) / test (official test set) never share a digit image
    pools = {"train": (xtr[:-5000], ytr[:-5000]), "val": (xtr[-5000:], ytr[-5000:]), "test": (xte, yte)}

    kw = dict(num_workers=a.workers, collate_fn=collate)
    train_loader = DataLoader(DigitSequences(*pools["train"], a.train_size), a.batch_size, shuffle=True, **kw)
    val_loader = DataLoader(DigitSequences(*pools["val"], a.eval_size, seed=10_000), 128, **kw)
    test_loader = DataLoader(DigitSequences(*pools["test"], a.eval_size, seed=20_000), 128, **kw)

    model = CRNN(num_classes=10).to(device)
    print(f"Device {device} | CRNN parameters: {sum(p.numel() for p in model.parameters()):,}")
    ctc = nn.CTCLoss(blank=0, zero_infinity=True)
    opt = torch.optim.Adam(model.parameters(), lr=a.lr)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=2)

    hist = {"train_loss": [], "val_loss": [], "val_seq_acc": [], "val_cer": []}
    best, ckpt = -1.0, os.path.join(a.model_dir, "crnn_digits.pt")
    for ep in range(1, a.epochs + 1):
        model.train()
        run, n = 0.0, 0
        for x, tgt, tlen in train_loader:
            out = model(x.to(device))
            ilen = torch.full((x.size(0),), out.size(0), dtype=torch.long)
            loss = ctc(out, tgt.to(device), ilen, tlen)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            run += loss.item() * x.size(0); n += x.size(0)
        m, _ = evaluate(model, val_loader, device, ctc)
        sched.step(m["loss"])
        for k, v in zip(hist, [run / n, m["loss"], m["seq_acc"], m["cer"]]):
            hist[k].append(v)
        flag = ""
        if m["seq_acc"] > best:
            best = m["seq_acc"]
            torch.save({"model_state": model.state_dict(), "charset": "0123456789"}, ckpt)
            flag = " *saved*"
        print(f"Epoch {ep:02d}/{a.epochs} | train CTC {run / n:.4f} | val CTC {m['loss']:.4f} "
              f"seq-acc {m['seq_acc']:.4f} CER {m['cer']:.4f}{flag}")

    model.load_state_dict(torch.load(ckpt, map_location=device, weights_only=True)["model_state"])
    res, shown = evaluate(model, test_loader, device, ctc)
    print(f"\nTEST  sequence accuracy: {res['seq_acc']:.4f} | character error rate: {res['cer']:.4f}")
    json.dump({"test": res, "best_val_seq_acc": best, "epochs": a.epochs},
              open(os.path.join(a.out_dir, "results.json"), "w"), indent=2)

    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(hist["train_loss"], label="train"); ax[0].plot(hist["val_loss"], label="val")
    ax[0].set_title("CTC loss"); ax[0].legend(); ax[0].set_xlabel("epoch")
    ax[1].plot(hist["val_seq_acc"], label="sequence accuracy"); ax[1].plot(hist["val_cer"], label="CER")
    ax[1].set_title("Validation"); ax[1].legend(); ax[1].set_xlabel("epoch")
    plt.tight_layout(); plt.savefig(os.path.join(a.out_dir, "training_curves.png"), dpi=150); plt.close()

    fig, axes = plt.subplots(6, 2, figsize=(10, 7))
    for ax, (img, truth, pred) in zip(axes.ravel(), shown):
        ax.imshow(img, cmap="gray"); ax.axis("off")
        ok = pred == truth
        ax.set_title(f"true {''.join(map(str, truth))} | pred {''.join(map(str, pred))}",
                     fontsize=9, color="green" if ok else "red")
    plt.tight_layout(); plt.savefig(os.path.join(a.out_dir, "sample_predictions.png"), dpi=150); plt.close()
    print(f"Saved {ckpt} and plots to {a.out_dir}/")


if __name__ == "__main__":
    main()
