"""Image processing for real-world handwriting photos/scans.

Pipeline: grayscale -> blur -> Otsu threshold (auto-detects dark-on-light or light-on-dark)
-> ink mask -> (connected components for words) -> crop -> stroke normalisation
-> scale to 20x20 and centre by centre-of-mass in a 28x28 canvas (the MNIST convention).
"""
import cv2
import numpy as np


def load_gray(path):
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {path}")
    return img


def to_ink_mask(gray):
    """Binary mask (uint8, 255 = ink) from a grayscale image of any polarity."""
    if gray.std() < 5:
        raise ValueError("Image has no visible ink (uniform image).")
    gray = cv2.GaussianBlur(gray, (3, 3), 0)
    border = np.concatenate([gray[0], gray[-1], gray[:, 0], gray[:, -1]])
    light_background = np.median(border) > 127
    flag = cv2.THRESH_BINARY_INV if light_background else cv2.THRESH_BINARY
    _, mask = cv2.threshold(gray, 0, 255, flag + cv2.THRESH_OTSU)
    return mask


def _stroke_width(mask):
    """Rough stroke width: 2 * area / perimeter."""
    contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    perimeter = sum(cv2.arcLength(c, True) for c in contours)
    area = float((mask > 0).sum())
    return 2.0 * area / perimeter if perimeter > 0 else 1.0


def mask_to_mnist(mask, box=20, size=28, target_stroke=2.2):
    """Convert a mask containing ONE character to a 28x28 MNIST-style uint8 image."""
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        raise ValueError("Empty mask - nothing to recognise.")
    crop = np.ascontiguousarray(mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1])
    h, w = crop.shape
    scale = box / max(h, w)

    # make pen strokes about as thick as MNIST strokes after scaling
    width = _stroke_width(crop)
    needed = target_stroke / scale - width
    if needed > 0:
        r = int(min(15, round(needed / 2)))
        if r >= 1:
            k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
            crop = cv2.dilate(cv2.copyMakeBorder(crop, r, r, r, r, cv2.BORDER_CONSTANT, value=0), k)
            h, w = crop.shape
            scale = box / max(h, w)

    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    crop = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_AREA)
    canvas = np.zeros((size, size), np.uint8)
    x0, y0 = (size - nw) // 2, (size - nh) // 2
    canvas[y0:y0 + nh, x0:x0 + nw] = crop

    m = cv2.moments(canvas)
    if m["m00"] > 0:                                       # centre of mass -> image centre
        cx, cy = m["m10"] / m["m00"], m["m01"] / m["m00"]
        shift = np.float32([[1, 0, size / 2 - cx], [0, 1, size / 2 - cy]])
        canvas = cv2.warpAffine(canvas, shift, (size, size))
    return canvas


def segment_characters(mask, merge_overlap=0.5, min_area_frac=0.03):
    """Split a line of text into characters.

    Connected components are merged when they overlap horizontally (dots of i/j, accents),
    sorted left-to-right and tiny specks are dropped.
    Returns a list of (character_mask, (x0, y0, x1, y1)).
    Limitation: touching/cursive letters are not separable this way (use the CRNN for that).
    """
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    boxes = [[x, y, x + w, y + h, a] for x, y, w, h, a in stats[1:]]
    boxes.sort(key=lambda b: b[0])

    merged = True
    while merged:                                          # merge horizontally overlapping boxes
        merged = False
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                a, b = boxes[i], boxes[j]
                overlap = min(a[2], b[2]) - max(a[0], b[0])
                if overlap > merge_overlap * min(a[2] - a[0], b[2] - b[0]):
                    boxes[i] = [min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]),
                                max(a[3], b[3]), a[4] + b[4]]
                    del boxes[j]
                    merged = True
                    break
            if merged:
                break

    if not boxes:
        return []
    max_area = max(b[4] for b in boxes)
    boxes = [b for b in boxes if b[4] >= min_area_frac * max_area]
    boxes.sort(key=lambda b: b[0])
    return [(mask[y0:y1, x0:x1], (x0, y0, x1, y1)) for x0, y0, x1, y1, _ in boxes]


def image_to_char(gray):
    """Whole image = one character."""
    return mask_to_mnist(to_ink_mask(gray))


def image_to_chars(gray):
    """Whole image = a line of characters. Returns (list of 28x28 images, list of boxes)."""
    mask = to_ink_mask(gray)
    segs = segment_characters(mask)
    return [mask_to_mnist(m) for m, _ in segs], [b for _, b in segs]
