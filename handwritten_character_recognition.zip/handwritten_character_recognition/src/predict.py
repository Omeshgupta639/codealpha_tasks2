"""Recognise handwritten characters from image files.

    python src/predict.py --model models/mnist_cnn.pt --image sample_inputs/digit_7.png
    python src/predict.py --model models/emnist_balanced_cnn.pt --word sample_inputs/word_HELLO.png --save_vis out.png
"""
import argparse
import os
import sys

import cv2
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(__file__))
from models import CNN  # noqa: E402
from preprocess import image_to_char, image_to_chars, load_gray  # noqa: E402


def load_model(path, device="cpu"):
    ck = torch.load(path, map_location=device, weights_only=True)
    model = CNN(len(ck["classes"])).to(device)
    model.load_state_dict(ck["model_state"])
    return model.eval(), ck


@torch.no_grad()
def classify(model, ck, imgs28, device="cpu", topk=3):
    """imgs28: list of 28x28 uint8 images (white ink on black). Returns top-k (label, prob) per image."""
    x = torch.from_numpy(np.stack(imgs28)).float().div(255).unsqueeze(1)
    x = ((x - ck["mean"]) / ck["std"]).to(device)
    p, idx = model(x).softmax(1).cpu().topk(min(topk, len(ck["classes"])), dim=1)
    return [[(ck["classes"][j], float(pp)) for pp, j in zip(p[i], idx[i])] for i in range(len(imgs28))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="checkpoint from train.py, e.g. models/mnist_cnn.pt")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--image", help="image containing ONE character")
    g.add_argument("--word", help="image containing a line of characters (segmented automatically)")
    ap.add_argument("--save_vis", help="save an annotated image (word mode)")
    a = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, ck = load_model(a.model, device)

    if a.image:
        res = classify(model, ck, [image_to_char(load_gray(a.image))], device)[0]
        print(f"Prediction: {res[0][0]}  ({res[0][1]:.1%})")
        print("Top-3:", ", ".join(f"{c} {p:.1%}" for c, p in res))
    else:
        gray = load_gray(a.word)
        chars, boxes = image_to_chars(gray)
        if not chars:
            raise SystemExit("No characters found.")
        results = classify(model, ck, chars, device)
        text = "".join(r[0][0] for r in results)
        print(f"Recognised text: {text}")
        for r, b in zip(results, boxes):
            print(f"  box {b}: {r[0][0]} ({r[0][1]:.1%})")
        if a.save_vis:
            vis = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
            for r, (x0, y0, x1, y1) in zip(results, boxes):
                cv2.rectangle(vis, (x0, y0), (x1, y1), (0, 160, 0), 1)
                cv2.putText(vis, r[0][0], (x0, max(12, y0 - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
            cv2.imwrite(a.save_vis, vis)
            print("Saved", a.save_vis)


if __name__ == "__main__":
    main()
