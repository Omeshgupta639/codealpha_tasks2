"""Model definitions: a CNN for single characters and a CRNN for sequences."""
import torch
import torch.nn as nn


def conv_block(cin, cout, p_drop=0.1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
        nn.Conv2d(cout, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
        nn.MaxPool2d(2), nn.Dropout2d(p_drop))


class CNN(nn.Module):
    """Input (B,1,28,28) -> logits (B,num_classes).

    3 x [conv-BN-ReLU x2 + maxpool + dropout] -> FC(256) -> FC(num_classes)
    """

    def __init__(self, num_classes):
        super().__init__()
        self.features = nn.Sequential(conv_block(1, 32), conv_block(32, 64), conv_block(64, 128))
        self.classifier = nn.Sequential(
            nn.Flatten(), nn.Linear(128 * 3 * 3, 256), nn.BatchNorm1d(256), nn.ReLU(inplace=True),
            nn.Dropout(0.4), nn.Linear(256, num_classes))

    def forward(self, x):
        return self.classifier(self.features(x))


class CRNN(nn.Module):
    """CNN feature extractor + bidirectional LSTM + CTC output layer.

    Input  (B,1,H,W) with H=28 (any W)
    Output (T,B,num_classes+1) log-probabilities, T = W/4. Index 0 is the CTC blank.
    Replace the training data with word images (e.g. IAM) to do real handwriting.
    """

    def __init__(self, num_classes, hidden=128):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(1, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True), nn.MaxPool2d(2, 2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(inplace=True), nn.MaxPool2d(2, 2),
            nn.Conv2d(128, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, None)))            # collapse height, keep width as time axis
        self.rnn = nn.LSTM(256, hidden, num_layers=2, bidirectional=True, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(2 * hidden, num_classes + 1)

    def forward(self, x):
        f = self.cnn(x).squeeze(2).permute(0, 2, 1)     # (B,T,256)
        out, _ = self.rnn(f)
        return self.fc(out).log_softmax(2).permute(1, 0, 2)   # (T,B,C) for CTCLoss
