"""Pure-numpy helpers for the CRNN demo (synthetic digit sequences, CTC decoding, metrics)."""
import numpy as np

MAX_LEN = 6
GAP_MAX = 3                      # random gap 0..3 px between digits
WIDTH = MAX_LEN * 32             # fixed canvas width (>= 3 + MAX_LEN * (28 + GAP_MAX))


def compose_sequence(images, labels, rng, min_len=3, max_len=MAX_LEN, width=WIDTH):
    """Paste random MNIST digits side by side. Returns (28 x width uint8 image, list of digit labels)."""
    length = int(rng.integers(min_len, max_len + 1))
    idx = rng.integers(0, len(images), length)
    canvas = np.zeros((28, width), np.uint8)
    x = int(rng.integers(0, 4))
    for i in idx:
        canvas[:, x:x + 28] = np.maximum(canvas[:, x:x + 28], images[i])
        x += 28 + int(rng.integers(0, GAP_MAX + 1))
    return canvas, [int(labels[i]) for i in idx]


def ctc_greedy_decode(log_probs, blank=0):
    """log_probs: (T, B, C) numpy array -> list of label-index sequences (collapse repeats, drop blanks)."""
    best = log_probs.argmax(2)                       # (T, B)
    out = []
    for b in range(best.shape[1]):
        seq, prev = [], blank
        for s in best[:, b]:
            if s != prev and s != blank:
                seq.append(int(s))
            prev = s
        out.append(seq)
    return out


def edit_distance(a, b):
    """Levenshtein distance between two sequences."""
    d = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(b) + 1):
            cur = d[j]
            d[j] = min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] != b[j - 1]))
            prev = cur
    return d[len(b)]
