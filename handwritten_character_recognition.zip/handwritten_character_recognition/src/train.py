"""Train and evaluate the CNN on MNIST / EMNIST.

    python src/train.py --dataset mnist --epochs 12
    python src/train.py --dataset emnist_balanced --epochs 20
    python src/train.py --dataset emnist_letters  --epochs 20
    python src/train.py --dataset mnist --epochs 1 --subset 0.05    # quick smoke test
"""
import argparse
import csv
import json
import os
import random
import sys
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
import torch.nn as nn
from sklearn.metrics import classification_report, confusion_matrix

sys.path.insert(0, os.path.dirname(__file__))
from data import CLASSES, get_loaders  # noqa: E402
from models import CNN  # noqa: E402


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)


def run_epoch(model, loader, criterion, device, optimizer=None, scheduler=None):
    train = optimizer is not None
    model.train(train)
    total_loss, correct, n = 0.0, 0, 0
    with torch.set_grad_enabled(train):
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            out = model(x)
            loss = criterion(out, y)
            if train:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
                if scheduler is not None:
                    scheduler.step()
            total_loss += loss.item() * len(y)
            correct += (out.argmax(1) == y).sum().item()
            n += len(y)
    return total_loss / n, correct / n


@torch.no_grad()
def predict_all(model, loader, device, mean, std, keep_wrong=25):
    model.eval()
    preds, labels, wrong = [], [], []
    for x, y in loader:
        p = model(x.to(device)).argmax(1).cpu()
        preds.append(p); labels.append(y)
        if len(wrong) < keep_wrong:
            for img, yt, yp in zip(x, y, p):
                if yt != yp and len(wrong) < keep_wrong:
                    wrong.append(((img[0] * std + mean).clamp(0, 1).numpy(), int(yt), int(yp)))
    return torch.cat(preds).numpy(), torch.cat(labels).numpy(), wrong


def plot_curves(h, path):
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(h["train_loss"], label="train"); ax[0].plot(h["val_loss"], label="val")
    ax[0].set_title("Loss"); ax[0].set_xlabel("epoch"); ax[0].legend()
    ax[1].plot(h["train_acc"], label="train"); ax[1].plot(h["val_acc"], label="val")
    ax[1].set_title("Accuracy"); ax[1].set_xlabel("epoch"); ax[1].legend()
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()


def plot_confusion(cm, classes, path):
    k = len(classes)
    size = max(6, k * 0.32)
    plt.figure(figsize=(size, size * 0.85))
    sns.heatmap(cm, annot=k <= 12, fmt="d", cmap="Blues", xticklabels=classes, yticklabels=classes,
                cbar=k <= 12)
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.title("Confusion matrix (test set)")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()


def plot_wrong(wrong, classes, path):
    if not wrong:
        return
    cols = 5
    rows = (len(wrong) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 2, rows * 2.2))
    for ax in np.atleast_1d(axes).ravel():
        ax.axis("off")
    for ax, (img, yt, yp) in zip(np.atleast_1d(axes).ravel(), wrong):
        ax.imshow(img, cmap="gray"); ax.set_title(f"true {classes[yt]} | pred {classes[yp]}", fontsize=8)
    plt.suptitle("Misclassified test examples"); plt.tight_layout()
    plt.savefig(path, dpi=150); plt.close()


def main():
    ap = argparse.ArgumentParser(description="Handwritten character recognition (CNN)")
    ap.add_argument("--dataset", default="mnist", choices=list(CLASSES))
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--batch_size", type=int, default=128)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--subset", type=float, default=1.0, help="fraction of training data (smoke tests)")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--data_dir", default="data")
    ap.add_argument("--out_dir", default="outputs")
    ap.add_argument("--model_dir", default="models")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    set_seed(a.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out = os.path.join(a.out_dir, a.dataset)
    os.makedirs(out, exist_ok=True); os.makedirs(a.model_dir, exist_ok=True)

    train_loader, val_loader, test_loader, classes, (mean, std) = get_loaders(
        a.dataset, a.data_dir, a.batch_size, a.workers, seed=a.seed, subset=a.subset)
    print(f"Device: {device} | dataset: {a.dataset} | classes: {len(classes)} | "
          f"train/val/test batches: {len(train_loader)}/{len(val_loader)}/{len(test_loader)}")

    model = CNN(len(classes)).to(device)
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")
    criterion = nn.CrossEntropyLoss(label_smoothing=0.05)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=a.lr, total_steps=a.epochs * len(train_loader))

    ckpt_path = os.path.join(a.model_dir, f"{a.dataset}_cnn.pt")
    hist = {k: [] for k in ["train_loss", "train_acc", "val_loss", "val_acc"]}
    best, t0 = 0.0, time.time()
    for ep in range(1, a.epochs + 1):
        trl, tra = run_epoch(model, train_loader, criterion, device, optimizer, scheduler)
        vl, va = run_epoch(model, val_loader, criterion, device)
        for k, v in zip(hist, [trl, tra, vl, va]):
            hist[k].append(v)
        flag = ""
        if va > best:
            best = va
            torch.save({"model_state": model.state_dict(), "classes": classes, "mean": mean,
                        "std": std, "dataset": a.dataset}, ckpt_path)
            flag = " *saved*"
        print(f"Epoch {ep:02d}/{a.epochs} | train loss {trl:.4f} acc {tra:.4f} | "
              f"val loss {vl:.4f} acc {va:.4f}{flag}")

    # ---- final evaluation on the official test set with the best checkpoint
    ck = torch.load(ckpt_path, map_location=device, weights_only=True)
    model.load_state_dict(ck["model_state"])
    preds, labels, wrong = predict_all(model, test_loader, device, mean, std)
    test_acc = float((preds == labels).mean())
    print(f"\nTEST ACCURACY: {test_acc:.4f}  ({len(labels)} images, best val acc {best:.4f})")
    report = classification_report(labels, preds, target_names=classes, digits=4, zero_division=0)
    print(report)

    cm = confusion_matrix(labels, preds, labels=list(range(len(classes))))
    per_class = cm.diagonal() / np.maximum(cm.sum(1), 1)
    with open(os.path.join(out, "per_class_accuracy.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["class", "accuracy", "support"])
        for c, acc, s in zip(classes, per_class, cm.sum(1)):
            w.writerow([c, f"{acc:.4f}", int(s)])
    open(os.path.join(out, "classification_report.txt"), "w").write(report)
    plot_curves(hist, os.path.join(out, "training_curves.png"))
    plot_confusion(cm, classes, os.path.join(out, "confusion_matrix.png"))
    plot_wrong(wrong, classes, os.path.join(out, "misclassified.png"))
    json.dump({"dataset": a.dataset, "num_classes": len(classes), "epochs": a.epochs,
               "best_val_acc": best, "test_acc": test_acc,
               "train_minutes": round((time.time() - t0) / 60, 2),
               "worst_classes": [classes[i] for i in np.argsort(per_class)[:5]]},
              open(os.path.join(out, "results.json"), "w"), indent=2)
    print(f"Saved model to {ckpt_path} and plots/results to {out}/")


if __name__ == "__main__":
    main()
