"""Datasets: MNIST (digits) and EMNIST (letters / balanced / byclass)."""
import torch
from PIL import Image
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

CLASSES = {
    "mnist": list("0123456789"),
    "emnist_letters": list("ABCDEFGHIJKLMNOPQRSTUVWXYZ"),                         # 26
    "emnist_balanced": list("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabdefghnqrt"),   # 47
    "emnist_byclass": list("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                           "abcdefghijklmnopqrstuvwxyz"),                         # 62
}
STATS = {"mnist": (0.1307, 0.3081), "emnist": (0.1751, 0.3332)}   # (mean, std) of pixel intensity


def fix_emnist(img):
    """EMNIST images are stored transposed; this makes them upright like MNIST."""
    return img.transpose(Image.Transpose.TRANSPOSE)


def shift_label(t):
    """EMNIST-letters labels run 1..26 -> 0..25."""
    return t - 1


def make_transform(name, train):
    mean, std = STATS["mnist" if name == "mnist" else "emnist"]
    ops = []
    if name != "mnist":
        ops.append(transforms.Lambda(fix_emnist))
    if train:
        ops.append(transforms.RandomAffine(degrees=10, translate=(0.1, 0.1), scale=(0.9, 1.1), shear=5))
    ops += [transforms.ToTensor(), transforms.Normalize((mean,), (std,))]
    return transforms.Compose(ops), (mean, std)


def get_dataset(name, root, train, transform):
    if name == "mnist":
        return datasets.MNIST(root, train=train, download=True, transform=transform)
    split = name.split("_", 1)[1]
    return datasets.EMNIST(root, split=split, train=train, download=True, transform=transform,
                           target_transform=shift_label if split == "letters" else None)


def get_loaders(name, root="data", batch_size=128, workers=2, val_frac=0.1, seed=42, subset=1.0):
    """Returns train/val/test loaders, class names and (mean, std).

    * 10% of the official training set is held out for validation (no augmentation on it)
    * the official test set is only used for the final evaluation
    * subset < 1 uses a fraction of the training data (handy for quick smoke tests)
    """
    tf_train, stats = make_transform(name, train=True)
    tf_plain, _ = make_transform(name, train=False)
    full_aug = get_dataset(name, root, True, tf_train)
    full_plain = get_dataset(name, root, True, tf_plain)
    test = get_dataset(name, root, False, tf_plain)

    g = torch.Generator().manual_seed(seed)
    perm = torch.randperm(len(full_aug), generator=g).tolist()
    n_val = int(len(perm) * val_frac)
    val_idx, train_idx = perm[:n_val], perm[n_val:]
    if subset < 1.0:
        train_idx = train_idx[: max(1, int(len(train_idx) * subset))]
        val_idx = val_idx[: max(1, int(len(val_idx) * subset))]

    kw = dict(num_workers=workers, pin_memory=torch.cuda.is_available())
    train_loader = DataLoader(Subset(full_aug, train_idx), batch_size, shuffle=True, drop_last=True, **kw)
    val_loader = DataLoader(Subset(full_plain, val_idx), 512, shuffle=False, **kw)
    test_loader = DataLoader(test, 512, shuffle=False, **kw)
    return train_loader, val_loader, test_loader, CLASSES[name], stats
